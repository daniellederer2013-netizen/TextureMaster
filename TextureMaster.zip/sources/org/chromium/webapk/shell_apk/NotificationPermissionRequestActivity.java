package org.chromium.webapk.shell_apk;

import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;
import android.util.Log;

/* compiled from: chromium-WebApk.apk-default-1 */
public class NotificationPermissionRequestActivity extends Activity {
    public static final /* synthetic */ int d = 0;
    public String a;
    public String b;
    public Messenger c;

    public final void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        if (Build.VERSION.SDK_INT < 33) {
            Log.w("PermissionRequestActivity", "Cannot request notification permission before Android T.");
            finish();
            return;
        }
        this.a = getIntent().getStringExtra("notificationChannelName");
        this.b = getIntent().getStringExtra("notificationChannelId");
        Messenger messenger = (Messenger) getIntent().getParcelableExtra("messenger");
        this.c = messenger;
        if (this.a == null || this.b == null || messenger == null) {
            Log.w("PermissionRequestActivity", "Finishing because not all required extras were provided.");
            finish();
            return;
        }
        if (getApplicationContext().getApplicationInfo().targetSdkVersion < 33) {
            ((NotificationManager) getSystemService("notification")).createNotificationChannel(new NotificationChannel(this.b, this.a, 3));
        }
        requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 0);
    }

    public final void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        boolean z = false;
        int i2 = 0;
        while (true) {
            if (i2 >= strArr.length) {
                break;
            } else if (!strArr[i2].equals("android.permission.POST_NOTIFICATIONS")) {
                i2++;
            } else {
                getApplicationContext().getSharedPreferences("org.chromium.webapk.shell_apk.PrefUtils", 0).edit().putBoolean("HAS_REQUESTED_NOTIFICATION_PERMISSION", true).apply();
                if (iArr[i2] == 0) {
                    z = true;
                }
            }
        }
        if (!z) {
            z = ((NotificationManager) getSystemService("notification")).areNotificationsEnabled();
        }
        Messenger messenger = this.c;
        Bundle bundle = new Bundle();
        bundle.putInt("permissionStatus", z ^ true ? 1 : 0);
        Message obtain = Message.obtain();
        obtain.setData(bundle);
        try {
            messenger.send(obtain);
        } catch (RemoteException e) {
            e.printStackTrace();
        }
        finish();
    }
}
