package org.chromium.webapk.shell_apk;

import android.app.Activity;
import android.os.Bundle;
import android.os.SystemClock;

/* compiled from: chromium-WebApk.apk-default-1 */
public class TransparentLauncherActivity extends Activity {
    public void a(e eVar) {
        if (eVar != null) {
            D.a(getApplicationContext(), eVar);
            C0003d.a(this, eVar, (Bundle) null, 268435456, false);
        }
    }

    public final void onCreate(Bundle bundle) {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        super.onCreate(bundle);
        new o(this).a(new y(this, elapsedRealtime));
    }
}
