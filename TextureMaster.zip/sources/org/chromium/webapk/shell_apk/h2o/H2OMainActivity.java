package org.chromium.webapk.shell_apk.h2o;

import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import org.chromium.webapk.shell_apk.TransparentLauncherActivity;

/* compiled from: chromium-WebApk.apk-default-1 */
public class H2OMainActivity extends TransparentLauncherActivity {
    public final void a(e eVar) {
        if (eVar != null) {
            Context applicationContext = getApplicationContext();
            if (g.b(eVar)) {
                if (System.currentTimeMillis() - B.a(applicationContext).getLong("org.chromium.webapk.shell_apk.request_host_browser_relaunch_timestamp", -1) > 20000) {
                    long currentTimeMillis = System.currentTimeMillis();
                    SharedPreferences.Editor edit = getSharedPreferences("org.chromium.webapk.shell_apk", 0).edit();
                    edit.putLong("org.chromium.webapk.shell_apk.request_host_browser_relaunch_timestamp", currentTimeMillis);
                    edit.apply();
                    Bundle bundle = new Bundle();
                    bundle.putBoolean("org.chromium.webapk.relaunch", true);
                    C0003d.a(this, eVar, bundle, 268435456, false);
                    ComponentName componentName = new ComponentName(applicationContext, H2OOpaqueMainActivity.class);
                    ComponentName componentName2 = getComponentName();
                    B.a(applicationContext).edit().commit();
                    PackageManager packageManager = applicationContext.getPackageManager();
                    packageManager.setComponentEnabledSetting(componentName, 1, 1);
                    packageManager.setComponentEnabledSetting(componentName2, 2, 0);
                    return;
                }
            }
            C0003d.a(this, eVar, (Bundle) null, 268435456, false);
        }
    }
}
