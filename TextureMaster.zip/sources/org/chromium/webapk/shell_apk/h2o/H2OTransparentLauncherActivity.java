package org.chromium.webapk.shell_apk.h2o;

import org.chromium.webapk.shell_apk.TransparentLauncherActivity;

/* compiled from: chromium-WebApk.apk-default-1 */
public class H2OTransparentLauncherActivity extends TransparentLauncherActivity {
    /* JADX WARNING: Code restructure failed: missing block: B:18:0x0068, code lost:
        r10 = null;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(defpackage.e r12) {
        /*
            r11 = this;
            if (r12 != 0) goto L_0x0003
            return
        L_0x0003:
            android.content.Context r0 = r11.getApplicationContext()
            defpackage.D.a(r0, r12)
            boolean r0 = defpackage.g.b(r12)
            android.content.Context r1 = r11.getApplicationContext()
            java.lang.Class<org.chromium.webapk.shell_apk.h2o.SplashActivity> r2 = org.chromium.webapk.shell_apk.h2o.SplashActivity.class
            r3 = 0
            boolean r4 = r12.a
            java.lang.Class<org.chromium.webapk.shell_apk.h2o.H2OMainActivity> r5 = org.chromium.webapk.shell_apk.h2o.H2OMainActivity.class
            r6 = 1
            if (r0 == 0) goto L_0x0047
            android.content.pm.PackageManager r7 = r1.getPackageManager()
            android.content.ComponentName r8 = new android.content.ComponentName
            java.lang.Class<org.chromium.webapk.shell_apk.h2o.H2OOpaqueMainActivity> r9 = org.chromium.webapk.shell_apk.h2o.H2OOpaqueMainActivity.class
            r8.<init>(r1, r9)
            int r7 = r7.getComponentEnabledSetting(r8)
            if (r7 != 0) goto L_0x003d
            if (r4 == 0) goto L_0x0040
            android.content.res.Resources r4 = r1.getResources()
            r6 = 2130837505(0x7f020001, float:1.7279966E38)
            boolean r4 = r4.getBoolean(r6)
            if (r4 == 0) goto L_0x0040
            goto L_0x0068
        L_0x003d:
            if (r7 != r6) goto L_0x0040
            goto L_0x0068
        L_0x0040:
            android.content.ComponentName r4 = new android.content.ComponentName
            r4.<init>(r1, r5)
        L_0x0045:
            r10 = r4
            goto L_0x0070
        L_0x0047:
            android.content.pm.PackageManager r7 = r1.getPackageManager()
            android.content.ComponentName r8 = new android.content.ComponentName
            r8.<init>(r1, r5)
            int r5 = r7.getComponentEnabledSetting(r8)
            if (r5 != 0) goto L_0x0066
            if (r4 == 0) goto L_0x0068
            android.content.res.Resources r4 = r1.getResources()
            r5 = 2130837506(0x7f020002, float:1.7279968E38)
            boolean r4 = r4.getBoolean(r5)
            if (r4 == 0) goto L_0x006a
            goto L_0x0068
        L_0x0066:
            if (r5 != r6) goto L_0x006a
        L_0x0068:
            r10 = r3
            goto L_0x0070
        L_0x006a:
            android.content.ComponentName r4 = new android.content.ComponentName
            r4.<init>(r1, r2)
            goto L_0x0045
        L_0x0070:
            if (r10 != 0) goto L_0x0090
            if (r0 == 0) goto L_0x0089
            android.content.Context r4 = r11.getApplicationContext()
            android.content.Intent r5 = r11.getIntent()
            android.content.ComponentName r9 = new android.content.ComponentName
            r9.<init>(r4, r2)
            java.lang.String r6 = r12.j
            long r7 = r12.h
            defpackage.C0001b.a(r4, r5, r6, r7, r9)
            return
        L_0x0089:
            r0 = 268435456(0x10000000, float:2.5243549E-29)
            r1 = 0
            defpackage.C0003d.a(r11, r12, r3, r0, r1)
            return
        L_0x0090:
            android.content.Context r5 = r11.getApplicationContext()
            android.content.Intent r6 = r11.getIntent()
            r8 = -1
            java.lang.String r7 = r12.j
            defpackage.C0001b.a(r5, r6, r7, r8, r10)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: org.chromium.webapk.shell_apk.h2o.H2OTransparentLauncherActivity.a(e):void");
    }
}
