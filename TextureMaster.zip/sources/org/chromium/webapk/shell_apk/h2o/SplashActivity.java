package org.chromium.webapk.shell_apk.h2o;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.Display;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import java.util.Iterator;

/* compiled from: chromium-WebApk.apk-default-1 */
public class SplashActivity extends Activity {
    public static final /* synthetic */ int g = 0;
    public AsyncTask a;
    public View b;
    public Bitmap c;
    public e d;
    public int e;
    public final p f = new p(new q(this));

    public final void a(byte[] bArr, Bitmap.CompressFormat compressFormat) {
        int width = this.b.getWidth();
        int height = this.b.getHeight();
        Bitmap.CompressFormat compressFormat2 = SplashContentProvider.b;
        SharedPreferences.Editor edit = B.a(this).edit();
        edit.putInt("org.chromium.webapk.shell_apk.splash_width", width);
        edit.putInt("org.chromium.webapk.shell_apk.splash_height", height);
        edit.apply();
        SplashContentProvider.b = compressFormat;
        SplashContentProvider.a(bArr);
        e eVar = this.d;
        String str = eVar.e;
        Log.v("cr_H2OLauncher", "WebAPK Launch URL: " + str);
        Bundle bundle = new Bundle();
        bundle.putBoolean("org.chromium.chrome.browser.webapk.splash_provided_by_webapk", true);
        C0003d.a(this, eVar, bundle, 65536, true);
        this.d = null;
    }

    public final void onActivityResult(int i, int i2, Intent intent) {
        if (this.e != 2 && i2 == 0) {
            this.e = 1;
        }
    }

    public final void onCreate(Bundle bundle) {
        int i;
        int i2;
        ComponentName componentName;
        super.onCreate(bundle);
        Bundle d2 = D.d(this);
        int a2 = (int) z.a(d2, "org.chromium.webapk.shell_apk.themeColor", -1);
        int a3 = (int) z.a(d2, "org.chromium.webapk.shell_apk.darkThemeColor", (long) ((int) z.a(d2, "org.chromium.webapk.shell_apk.themeColor", -16777216)));
        if (!D.b(this)) {
            a3 = a2;
        }
        Window window = getWindow();
        window.addFlags(Integer.MIN_VALUE);
        if (D.c(this)) {
            window.setStatusBarColor(-16777216);
        } else {
            window.setStatusBarColor(a3);
        }
        boolean e2 = D.e(a2);
        View rootView = getWindow().getDecorView().getRootView();
        int systemUiVisibility = rootView.getSystemUiVisibility();
        if (e2 || D.c(this)) {
            i = systemUiVisibility & -8193;
        } else {
            i = systemUiVisibility | 8192;
        }
        rootView.setSystemUiVisibility(i);
        String string = d2.getString("org.chromium.webapk.shell_apk.orientation");
        if (string == null || !string.equals("natural")) {
            i2 = -1;
        } else {
            Display defaultDisplay = ((WindowManager) getSystemService("window")).getDefaultDisplay();
            int rotation = defaultDisplay.getRotation();
            i2 = 0;
            if (rotation == 0 || rotation == 2 ? defaultDisplay.getHeight() >= defaultDisplay.getWidth() : defaultDisplay.getHeight() < defaultDisplay.getWidth()) {
                i2 = 1;
            }
        }
        if (i2 != -1) {
            setRequestedOrientation(i2);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            this.b = x.a(this);
        } else {
            this.b = w.a(this);
        }
        this.b.getViewTreeObserver().addOnGlobalLayoutListener(new s(this));
        setContentView(this.b);
        long elapsedRealtime = SystemClock.elapsedRealtime();
        ComponentName componentName2 = new ComponentName(this, SplashActivity.class);
        int taskId = getTaskId();
        Iterator<ActivityManager.AppTask> it = ((ActivityManager) getSystemService("activity")).getAppTasks().iterator();
        while (true) {
            if (!it.hasNext()) {
                componentName = null;
                break;
            }
            try {
                ActivityManager.RecentTaskInfo taskInfo = it.next().getTaskInfo();
                if (taskInfo != null && taskInfo.id == taskId) {
                    componentName = taskInfo.topActivity;
                    break;
                }
            } catch (IllegalArgumentException unused) {
            }
        }
        if (componentName2.equals(componentName)) {
            new o(this).a(new r(this, elapsedRealtime));
        }
    }

    public final void onDestroy() {
        SplashContentProvider.a((byte[]) null);
        AsyncTask asyncTask = this.a;
        if (asyncTask != null) {
            asyncTask.cancel(false);
            this.a = null;
        }
        super.onDestroy();
    }

    public final void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        this.e = 2;
        p pVar = this.f;
        pVar.e = false;
        pVar.d = false;
        pVar.c = false;
        new o(this).a(new r(this, -1));
    }

    public final void onResume() {
        super.onResume();
        if (this.e == 1) {
            finish();
            return;
        }
        this.e = 0;
        p pVar = this.f;
        pVar.c = true;
        pVar.a();
    }
}
