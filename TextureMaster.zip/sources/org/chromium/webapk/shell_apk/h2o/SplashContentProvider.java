package org.chromium.webapk.shell_apk.h2o;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelFileDescriptor;
import android.view.View;
import java.io.FileOutputStream;
import java.util.concurrent.atomic.AtomicReference;

/* compiled from: chromium-WebApk.apk-default-1 */
public class SplashContentProvider extends ContentProvider implements ContentProvider.PipeDataWriter {
    public static Bitmap.CompressFormat b;
    public static final AtomicReference c = new AtomicReference();
    public String a;

    /* JADX WARNING: type inference failed for: r1v3, types: [v, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r2v0, types: [java.lang.Object, java.lang.Runnable] */
    public static byte[] a(byte[] bArr) {
        Object obj;
        if (bArr != null) {
            ? obj2 = new Object();
            ? obj3 = new Object();
            obj3.a = bArr;
            Handler handler = new Handler();
            obj3.b = handler;
            handler.postDelayed(obj2, 10000);
            obj = obj3;
        } else {
            obj = null;
        }
        v vVar = (v) c.getAndSet(obj);
        if (vVar == null) {
            return null;
        }
        vVar.b.removeCallbacksAndMessages((Object) null);
        return vVar.a;
    }

    public final Bitmap b() {
        View view;
        Context applicationContext = getContext().getApplicationContext();
        SharedPreferences a2 = B.a(applicationContext);
        int i = a2.getInt("org.chromium.webapk.shell_apk.splash_width", -1);
        int i2 = a2.getInt("org.chromium.webapk.shell_apk.splash_height", -1);
        if (i > 0 && i2 > 0) {
            if (Build.VERSION.SDK_INT >= 31) {
                view = x.a(applicationContext);
            } else {
                view = w.a(applicationContext);
            }
            view.measure(View.MeasureSpec.makeMeasureSpec(i, 1073741824), View.MeasureSpec.makeMeasureSpec(i2, 1073741824));
            view.layout(0, 0, i, i2);
            int width = view.getWidth();
            int height = view.getHeight();
            if (!(width == 0 || height == 0)) {
                float min = Math.min(1.0f, ((float) 12582912) / ((float) ((width * 4) * height)));
                int round = Math.round(((float) width) * min);
                int round2 = Math.round(((float) height) * min);
                Matrix matrix = new Matrix();
                matrix.postScale(min, min);
                Bitmap createBitmap = Bitmap.createBitmap(round, round2, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(createBitmap);
                canvas.concat(matrix);
                view.draw(canvas);
                return createBitmap;
            }
        }
        return null;
    }

    public final int delete(Uri uri, String str, String[] strArr) {
        throw new UnsupportedOperationException();
    }

    public final String getType(Uri uri) {
        Bitmap.CompressFormat compressFormat;
        if (uri == null || !uri.toString().equals(this.a)) {
            return null;
        }
        if (b == null) {
            SharedPreferences a2 = B.a(getContext().getApplicationContext());
            if (a2.getInt("org.chromium.webapk.shell_apk.splash_height", -1) * a2.getInt("org.chromium.webapk.shell_apk.splash_width", -1) <= 1048576) {
                compressFormat = Bitmap.CompressFormat.PNG;
            } else {
                compressFormat = Bitmap.CompressFormat.JPEG;
            }
            b = compressFormat;
        }
        if (b == Bitmap.CompressFormat.PNG) {
            return "image/png";
        }
        if (b == Bitmap.CompressFormat.JPEG) {
            return "image/jpeg";
        }
        return null;
    }

    public final Uri insert(Uri uri, ContentValues contentValues) {
        throw new UnsupportedOperationException();
    }

    public final boolean onCreate() {
        this.a = "content://" + (getContext().getPackageName() + ".SplashContentProvider") + "/cached_splash_image";
        return true;
    }

    public final ParcelFileDescriptor openFile(Uri uri, String str) {
        if (uri == null || !uri.toString().equals(this.a)) {
            return null;
        }
        return openPipeHelper((Uri) null, (String) null, (Bundle) null, (Object) null, this);
    }

    public final Cursor query(Uri uri, String[] strArr, String str, String[] strArr2, String str2) {
        throw new UnsupportedOperationException();
    }

    public final int update(Uri uri, ContentValues contentValues, String str, String[] strArr) {
        throw new UnsupportedOperationException();
    }

    public final void writeDataToPipe(ParcelFileDescriptor parcelFileDescriptor, Uri uri, String str, Bundle bundle, Object obj) {
        FileOutputStream fileOutputStream;
        Bitmap.CompressFormat compressFormat;
        Void voidR = (Void) obj;
        try {
            fileOutputStream = new FileOutputStream(parcelFileDescriptor.getFileDescriptor());
            byte[] a2 = a((byte[]) null);
            if (a2 != null) {
                fileOutputStream.write(a2);
            } else {
                Bitmap b2 = b();
                if (b2 != null) {
                    if (b2.getWidth() * b2.getHeight() <= 1048576) {
                        compressFormat = Bitmap.CompressFormat.PNG;
                    } else {
                        compressFormat = Bitmap.CompressFormat.JPEG;
                    }
                    b = compressFormat;
                    b2.compress(compressFormat, 100, fileOutputStream);
                }
            }
            fileOutputStream.flush();
            fileOutputStream.close();
            return;
        } catch (Exception unused) {
            return;
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
    }
}
