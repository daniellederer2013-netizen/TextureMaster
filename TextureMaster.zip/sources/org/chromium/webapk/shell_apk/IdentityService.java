package org.chromium.webapk.shell_apk;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

/* compiled from: chromium-WebApk.apk-default-1 */
public class IdentityService extends Service {
    public final h a = new h(this);

    public final IBinder onBind(Intent intent) {
        return this.a;
    }
}
