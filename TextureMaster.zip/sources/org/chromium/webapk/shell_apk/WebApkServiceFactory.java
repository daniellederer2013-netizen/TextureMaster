package org.chromium.webapk.shell_apk;

import android.app.Service;

/* compiled from: chromium-WebApk.apk-default-1 */
public class WebApkServiceFactory extends Service {
    /* JADX WARNING: Code restructure failed: missing block: B:34:0x0092, code lost:
        r0 = th;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:35:0x0093, code lost:
        r2 = r15;
     */
    /* JADX WARNING: Code restructure failed: missing block: B:44:?, code lost:
        r2.close();
     */
    /* JADX WARNING: Code restructure failed: missing block: B:47:0x00a3, code lost:
        if (r15 == null) goto L_0x00a6;
     */
    /* JADX WARNING: Failed to process nested try/catch */
    /* JADX WARNING: Removed duplicated region for block: B:101:0x0188  */
    /* JADX WARNING: Removed duplicated region for block: B:102:0x018f A[SYNTHETIC, Splitter:B:102:0x018f] */
    /* JADX WARNING: Removed duplicated region for block: B:34:0x0092 A[ExcHandler: all (th java.lang.Throwable), Splitter:B:28:0x0087] */
    /* JADX WARNING: Removed duplicated region for block: B:43:0x009f A[SYNTHETIC, Splitter:B:43:0x009f] */
    /* JADX WARNING: Removed duplicated region for block: B:90:0x0172 A[SYNTHETIC, Splitter:B:90:0x0172] */
    /* JADX WARNING: Removed duplicated region for block: B:94:0x0177 A[SYNTHETIC, Splitter:B:94:0x0177] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final android.os.IBinder onBind(android.content.Intent r17) {
        /*
            r16 = this;
            r1 = r16
            f r0 = defpackage.g.a(r1)
            r2 = 0
            if (r0 == 0) goto L_0x000d
            java.lang.String r0 = r0.a
            r3 = r0
            goto L_0x000e
        L_0x000d:
            r3 = r2
        L_0x000e:
            java.util.HashSet r0 = defpackage.g.a
            boolean r0 = r0.contains(r3)
            java.lang.String r4 = "cr_WebApkServiceFactory"
            if (r0 != 0) goto L_0x001e
            java.lang.String r0 = "Host browser does not support WebAPK notification delegation."
            android.util.Log.w(r4, r0)
            return r2
        L_0x001e:
            android.os.Looper r0 = android.os.Looper.getMainLooper()
            android.os.Looper r5 = android.os.Looper.myLooper()
            boolean r0 = r0.equals(r5)
            if (r0 == 0) goto L_0x01df
            r5 = 0
            android.content.Context r0 = r1.getApplicationContext()     // Catch:{ NameNotFoundException -> 0x0036 }
            android.content.Context r0 = r0.createPackageContext(r3, r5)     // Catch:{ NameNotFoundException -> 0x0036 }
            goto L_0x003b
        L_0x0036:
            r0 = move-exception
            r0.printStackTrace()
            r0 = r2
        L_0x003b:
            r6 = -1
            java.lang.String r7 = "org.chromium.webapk.lib.runtime_library.WebApkServiceImpl"
            java.lang.String r8 = "cr_HostBrowserClassLoader"
            if (r0 != 0) goto L_0x004a
            java.lang.String r0 = "Failed to get remote context."
            android.util.Log.w(r8, r0)
            r10 = r2
            goto L_0x0186
        L_0x004a:
            dalvik.system.BaseDexClassLoader r9 = defpackage.C0002c.a
            java.lang.String r10 = "org.chromium.webapk.shell_apk"
            java.lang.String r11 = "org.chromium.webapk.shell_apk.version_code"
            if (r9 == 0) goto L_0x0062
            android.content.SharedPreferences r9 = r1.getSharedPreferences(r10, r5)
            int r9 = r9.getInt(r11, r6)
            int r12 = defpackage.C0002c.a(r0)
            if (r12 != r9) goto L_0x0062
            goto L_0x0183
        L_0x0062:
            android.content.SharedPreferences r9 = r1.getSharedPreferences(r10, r5)
            java.lang.String r10 = "org.chromium.webapk.shell_apk.dex_version"
            int r12 = r9.getInt(r10, r6)
            int r13 = defpackage.C0002c.a(r0)
            int r14 = r9.getInt(r11, r6)
            if (r14 != r13) goto L_0x0078
            r2 = r6
            goto L_0x00b3
        L_0x0078:
            java.lang.String r14 = "webapk_dex_version.txt"
            java.util.Scanner r15 = new java.util.Scanner     // Catch:{ Exception -> 0x009a, all -> 0x0097 }
            android.content.res.AssetManager r2 = r0.getAssets()     // Catch:{ Exception -> 0x009a, all -> 0x0097 }
            java.io.InputStream r2 = r2.open(r14)     // Catch:{ Exception -> 0x009a, all -> 0x0097 }
            r15.<init>(r2)     // Catch:{ Exception -> 0x009a, all -> 0x0097 }
            int r2 = r15.nextInt()     // Catch:{ Exception -> 0x0095, all -> 0x0092 }
            r15.close()     // Catch:{ Exception -> 0x00a3, all -> 0x0092 }
        L_0x008e:
            r15.close()     // Catch:{ Exception -> 0x00a6 }
            goto L_0x00a6
        L_0x0092:
            r0 = move-exception
            r2 = r15
            goto L_0x009d
        L_0x0095:
            r2 = r6
            goto L_0x00a3
        L_0x0097:
            r0 = move-exception
            r2 = 0
            goto L_0x009d
        L_0x009a:
            r2 = r6
            r15 = 0
            goto L_0x00a3
        L_0x009d:
            if (r2 == 0) goto L_0x00a2
            r2.close()     // Catch:{ Exception -> 0x00a2 }
        L_0x00a2:
            throw r0
        L_0x00a3:
            if (r15 == 0) goto L_0x00a6
            goto L_0x008e
        L_0x00a6:
            android.content.SharedPreferences$Editor r9 = r9.edit()
            r9.putInt(r11, r13)
            r9.putInt(r10, r2)
            r9.apply()
        L_0x00b3:
            if (r2 != r6) goto L_0x00b6
            r2 = r12
        L_0x00b6:
            java.lang.String r9 = "dex"
            java.io.File r9 = r1.getDir(r9, r5)
            if (r2 == r12) goto L_0x00c6
            java.lang.String r10 = "Delete cached dex files."
            android.util.Log.w(r8, r10)
            defpackage.C0000a.a(r9)
        L_0x00c6:
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            java.lang.String r10 = "webapk"
            r8.<init>(r10)
            r8.append(r2)
            java.lang.String r2 = ".dex"
            r8.append(r2)
            java.lang.String r2 = r8.toString()
            java.io.File r8 = new java.io.File
            r8.<init>(r9, r2)
            boolean r10 = r8.exists()
            java.lang.String r11 = "cr.DexLoader"
            if (r10 == 0) goto L_0x00f0
            long r12 = r8.length()
            r14 = 0
            int r10 = (r12 > r14 ? 1 : (r12 == r14 ? 0 : -1))
            if (r10 != 0) goto L_0x0120
        L_0x00f0:
            boolean r10 = r9.exists()
            if (r10 != 0) goto L_0x00ff
            boolean r10 = r9.mkdirs()
            if (r10 != 0) goto L_0x00ff
        L_0x00fc:
            r0 = 0
            goto L_0x0181
        L_0x00ff:
            android.content.res.AssetManager r0 = r0.getAssets()     // Catch:{ IOException -> 0x016e }
            java.io.InputStream r0 = r0.open(r2)     // Catch:{ IOException -> 0x016e }
            java.io.FileOutputStream r2 = new java.io.FileOutputStream     // Catch:{ IOException -> 0x016c }
            r2.<init>(r8)     // Catch:{ IOException -> 0x016c }
            r10 = 16384(0x4000, float:2.2959E-41)
            byte[] r12 = new byte[r10]     // Catch:{ IOException -> 0x0170 }
        L_0x0110:
            int r13 = r0.read(r12, r5, r10)     // Catch:{ IOException -> 0x0170 }
            if (r13 == r6) goto L_0x011a
            r2.write(r12, r5, r13)     // Catch:{ IOException -> 0x0170 }
            goto L_0x0110
        L_0x011a:
            r0.close()     // Catch:{ IOException -> 0x0170 }
            r2.close()     // Catch:{ IOException -> 0x0170 }
        L_0x0120:
            java.io.File r2 = new java.io.File
            java.lang.String r0 = "optimized"
            r2.<init>(r9, r0)
            boolean r0 = r2.exists()
            if (r0 != 0) goto L_0x0134
            boolean r0 = r2.mkdirs()
            if (r0 != 0) goto L_0x0134
            goto L_0x00fc
        L_0x0134:
            dalvik.system.BaseDexClassLoader r0 = new dalvik.system.BaseDexClassLoader     // Catch:{ Exception -> 0x0146 }
            java.lang.String r5 = r8.getPath()     // Catch:{ Exception -> 0x0146 }
            java.lang.ClassLoader r9 = java.lang.ClassLoader.getSystemClassLoader()     // Catch:{ Exception -> 0x0146 }
            r10 = 0
            r0.<init>(r5, r2, r10, r9)     // Catch:{ Exception -> 0x0146 }
            r0.loadClass(r7)     // Catch:{ Exception -> 0x0146 }
            goto L_0x0181
        L_0x0146:
            r0 = move-exception
            java.lang.String r2 = r2.getPath()
            java.lang.String r5 = r8.getPath()
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            java.lang.String r9 = "Could not load dex from "
            r8.<init>(r9)
            r8.append(r5)
            java.lang.String r5 = " with optimized directory "
            r8.append(r5)
            r8.append(r2)
            java.lang.String r2 = r8.toString()
            android.util.Log.w(r11, r2)
            r0.printStackTrace()
            goto L_0x00fc
        L_0x016c:
            r2 = 0
            goto L_0x0170
        L_0x016e:
            r0 = 0
            goto L_0x016c
        L_0x0170:
            if (r0 == 0) goto L_0x0175
            r0.close()     // Catch:{ IOException -> 0x0175 }
        L_0x0175:
            if (r2 == 0) goto L_0x017a
            r2.close()     // Catch:{ IOException -> 0x017a }
        L_0x017a:
            java.lang.String r0 = "Could not extract dex from assets"
            android.util.Log.w(r11, r0)
            goto L_0x00fc
        L_0x0181:
            defpackage.C0002c.a = r0
        L_0x0183:
            dalvik.system.BaseDexClassLoader r0 = defpackage.C0002c.a
            r10 = r0
        L_0x0186:
            if (r10 != 0) goto L_0x018f
            java.lang.String r0 = "Unable to create ClassLoader."
            android.util.Log.w(r4, r0)
        L_0x018d:
            r10 = 0
            return r10
        L_0x018f:
            java.lang.Class r0 = r10.loadClass(r7)     // Catch:{ Exception -> 0x01d5 }
            java.lang.Class<android.content.Context> r2 = android.content.Context.class
            java.lang.Class<android.os.Bundle> r5 = android.os.Bundle.class
            java.lang.Class[] r2 = new java.lang.Class[]{r2, r5}     // Catch:{ Exception -> 0x01d5 }
            java.lang.reflect.Constructor r2 = r0.getConstructor(r2)     // Catch:{ Exception -> 0x01d5 }
            if (r3 != 0) goto L_0x01a2
            goto L_0x01b3
        L_0x01a2:
            android.content.pm.PackageManager r0 = r1.getPackageManager()     // Catch:{ NameNotFoundException -> 0x01af }
            r5 = 128(0x80, float:1.794E-43)
            android.content.pm.ApplicationInfo r0 = r0.getApplicationInfo(r3, r5)     // Catch:{ NameNotFoundException -> 0x01af }
            int r6 = r0.uid     // Catch:{ NameNotFoundException -> 0x01af }
            goto L_0x01b3
        L_0x01af:
            r0 = move-exception
            r0.printStackTrace()     // Catch:{ Exception -> 0x01d5 }
        L_0x01b3:
            android.os.Bundle r0 = new android.os.Bundle     // Catch:{ Exception -> 0x01d5 }
            r0.<init>()     // Catch:{ Exception -> 0x01d5 }
            java.lang.String r3 = "small_icon_id"
            r5 = 2131034114(0x7f050002, float:1.7678736E38)
            r0.putInt(r3, r5)     // Catch:{ Exception -> 0x01d5 }
            java.lang.String r3 = "host_browser_uid"
            r0.putInt(r3, r6)     // Catch:{ Exception -> 0x01d5 }
            java.lang.Object[] r0 = new java.lang.Object[]{r1, r0}     // Catch:{ Exception -> 0x01d5 }
            java.lang.Object r0 = r2.newInstance(r0)     // Catch:{ Exception -> 0x01d5 }
            android.os.IBinder r0 = (android.os.IBinder) r0     // Catch:{ Exception -> 0x01d5 }
            A r2 = new A     // Catch:{ Exception -> 0x01d5 }
            r2.<init>(r1, r0, r6)     // Catch:{ Exception -> 0x01d5 }
            return r2
        L_0x01d5:
            r0 = move-exception
            java.lang.String r2 = "Unable to create WebApkServiceImpl."
            android.util.Log.w(r4, r2)
            r0.printStackTrace()
            goto L_0x018d
        L_0x01df:
            java.lang.AssertionError r0 = new java.lang.AssertionError
            r0.<init>()
            throw r0
        */
        throw new UnsupportedOperationException("Method not decompiled: org.chromium.webapk.shell_apk.WebApkServiceFactory.onBind(android.content.Intent):android.os.IBinder");
    }
}
