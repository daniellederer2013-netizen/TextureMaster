package defpackage;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import dalvik.system.BaseDexClassLoader;

/* renamed from: c  reason: default package and case insensitive filesystem */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract class C0002c {
    public static BaseDexClassLoader a;

    public static int a(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (PackageManager.NameNotFoundException unused) {
            Log.e("cr_HostBrowserClassLoader", "Failed to get remote package info.");
            return -1;
        }
    }
}
