package defpackage;

import org.chromium.webapk.shell_apk.TransparentLauncherActivity;

/* renamed from: y  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class y implements n {
    public final /* synthetic */ long a;
    public final /* synthetic */ TransparentLauncherActivity b;

    public y(TransparentLauncherActivity transparentLauncherActivity, long j) {
        this.a = j;
        this.b = transparentLauncherActivity;
    }

    public final void a(f fVar, boolean z) {
        TransparentLauncherActivity transparentLauncherActivity = this.b;
        if (fVar == null) {
            transparentLauncherActivity.finish();
            return;
        }
        transparentLauncherActivity.a(e.a(transparentLauncherActivity, transparentLauncherActivity.getIntent(), fVar, z, this.a, -1));
        transparentLauncherActivity.finish();
    }
}
