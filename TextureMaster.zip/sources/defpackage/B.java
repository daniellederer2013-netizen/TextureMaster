package defpackage;

import android.content.Context;
import android.content.SharedPreferences;

/* renamed from: B  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract class B {
    public static SharedPreferences a(Context context) {
        return context.getSharedPreferences("org.chromium.webapk.shell_apk", 0);
    }
}
