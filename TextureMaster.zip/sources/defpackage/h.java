package defpackage;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import org.chromium.webapk.shell_apk.IdentityService;

/* renamed from: h  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class h extends Binder implements IInterface {
    public final /* synthetic */ IdentityService a;

    public h(IdentityService identityService) {
        this.a = identityService;
        attachInterface(this, "org.chromium.webapk.lib.common.identity_service.IIdentityService");
    }

    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        if (i >= 1 && i <= 16777215) {
            parcel.enforceInterface("org.chromium.webapk.lib.common.identity_service.IIdentityService");
        }
        if (i == 1598968902) {
            parcel2.writeString("org.chromium.webapk.lib.common.identity_service.IIdentityService");
            return true;
        } else if (i != 1) {
            return super.onTransact(i, parcel, parcel2, i2);
        } else {
            f a2 = g.a(this.a.getApplicationContext());
            String str = a2 != null ? a2.a : null;
            parcel2.writeNoException();
            parcel2.writeString(str);
            return true;
        }
    }

    public final IBinder asBinder() {
        return this;
    }
}
