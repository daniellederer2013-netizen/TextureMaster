package defpackage;

import android.util.Log;
import java.io.File;

/* renamed from: a  reason: default package and case insensitive filesystem */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract class C0000a {
    public static void a(File file) {
        File[] listFiles;
        if (file != null) {
            if (file.isDirectory() && (listFiles = file.listFiles()) != null) {
                for (File a : listFiles) {
                    a(a);
                }
            }
            if (!file.delete()) {
                Log.e("cr.DexLoader", "Failed to delete : " + file.getAbsolutePath());
            }
        }
    }
}
