package defpackage;

import android.os.Binder;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import org.chromium.webapk.shell_apk.WebApkServiceFactory;

/* renamed from: A  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class A extends Binder implements IInterface {
    public final int a;
    public final IBinder b;
    public final WebApkServiceFactory c;

    public A(WebApkServiceFactory webApkServiceFactory, IBinder iBinder, int i) {
        attachInterface(this, "org.chromium.webapk.lib.runtime_library.IWebApkApi");
        this.c = webApkServiceFactory;
        this.b = iBinder;
        this.a = i;
    }

    public final int a(String str) {
        IBinder iBinder = this.b;
        if (iBinder == null) {
            return -1;
        }
        try {
            Field declaredField = iBinder.getClass().getSuperclass().getDeclaredField(str);
            declaredField.setAccessible(true);
            return ((Integer) declaredField.get((Object) null)).intValue();
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v0, resolved type: android.app.PendingIntent} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v1, resolved type: android.app.PendingIntent} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v5, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v6, resolved type: android.app.PendingIntent} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v8, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v9, resolved type: android.app.PendingIntent} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v13, resolved type: android.app.PendingIntent} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v14, resolved type: android.app.PendingIntent} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r4v15, resolved type: android.app.PendingIntent} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final boolean b(int r8, android.os.Parcel r9, android.os.Parcel r10, int r11) {
        /*
            r7 = this;
            org.chromium.webapk.shell_apk.WebApkServiceFactory r0 = r7.c
            java.lang.String r1 = "org.chromium.webapk.lib.runtime_library.IWebApkApi"
            r2 = 1
            if (r8 < r2) goto L_0x000f
            r3 = 16777215(0xffffff, float:2.3509886E-38)
            if (r8 > r3) goto L_0x000f
            r9.enforceInterface(r1)
        L_0x000f:
            r3 = 1598968902(0x5f4e5446, float:1.4867585E19)
            if (r8 == r3) goto L_0x0155
            java.lang.String r1 = "notification"
            r3 = 0
            r4 = 0
            r5 = 33
            java.lang.String r6 = "cr_WebApkServiceImplWrapper"
            switch(r8) {
                case 1: goto L_0x0148;
                case 2: goto L_0x00df;
                case 3: goto L_0x00d0;
                case 4: goto L_0x00c4;
                case 5: goto L_0x00a4;
                case 6: goto L_0x0098;
                case 7: goto L_0x006d;
                case 8: goto L_0x0024;
                default: goto L_0x001f;
            }
        L_0x001f:
            boolean r8 = super.onTransact(r8, r9, r10, r11)
            return r8
        L_0x0024:
            java.lang.String r8 = r9.readString()
            java.lang.String r9 = r9.readString()
            int r11 = android.os.Build.VERSION.SDK_INT
            if (r11 >= r5) goto L_0x0036
            java.lang.String r8 = "Cannot request notification permission before Android T."
            android.util.Log.w(r6, r8)
            goto L_0x005d
        L_0x0036:
            int r1 = org.chromium.webapk.shell_apk.NotificationPermissionRequestActivity.d
            android.content.Intent r1 = new android.content.Intent
            android.content.Context r4 = r0.getApplicationContext()
            java.lang.Class<org.chromium.webapk.shell_apk.NotificationPermissionRequestActivity> r5 = org.chromium.webapk.shell_apk.NotificationPermissionRequestActivity.class
            r1.<init>(r4, r5)
            java.lang.String r4 = "notificationChannelName"
            r1.putExtra(r4, r8)
            java.lang.String r8 = "notificationChannelId"
            r1.putExtra(r8, r9)
            r8 = 31
            if (r11 < r8) goto L_0x0054
            r8 = 33554432(0x2000000, float:9.403955E-38)
            goto L_0x0055
        L_0x0054:
            r8 = r3
        L_0x0055:
            android.content.Context r9 = r0.getApplicationContext()
            android.app.PendingIntent r4 = android.app.PendingIntent.getActivity(r9, r3, r1, r8)
        L_0x005d:
            r10.writeNoException()
            if (r4 == 0) goto L_0x0069
            r10.writeInt(r2)
            r4.writeToParcel(r10, r2)
            return r2
        L_0x0069:
            r10.writeInt(r3)
            return r2
        L_0x006d:
            java.lang.Object r8 = r0.getSystemService(r1)
            android.app.NotificationManager r8 = (android.app.NotificationManager) r8
            boolean r8 = r8.areNotificationsEnabled()
            r8 = r8 ^ r2
            if (r8 != r2) goto L_0x0091
            android.content.Context r9 = r0.getApplicationContext()
            java.lang.String r11 = "org.chromium.webapk.shell_apk.PrefUtils"
            android.content.SharedPreferences r9 = r9.getSharedPreferences(r11, r3)
            java.lang.String r11 = "HAS_REQUESTED_NOTIFICATION_PERMISSION"
            boolean r9 = r9.getBoolean(r11, r3)
            if (r9 != 0) goto L_0x0091
            int r9 = android.os.Build.VERSION.SDK_INT
            if (r9 < r5) goto L_0x0091
            r8 = 2
        L_0x0091:
            r10.writeNoException()
            r10.writeInt(r8)
            return r2
        L_0x0098:
            java.lang.String r8 = "Should NOT reach WebApkServiceImplWrapper#finishAndRemoveTaskSdk23()"
            android.util.Log.w(r6, r8)
            r10.writeNoException()
            r10.writeInt(r3)
            return r2
        L_0x00a4:
            r9.readString()
            r9.readInt()
            android.os.Parcelable$Creator r8 = android.app.Notification.CREATOR
            int r11 = r9.readInt()
            if (r11 == 0) goto L_0x00b6
            java.lang.Object r4 = r8.createFromParcel(r9)
        L_0x00b6:
            android.app.Notification r4 = (android.app.Notification) r4
            r9.readString()
            java.lang.String r8 = "Should NOT reach WebApkServiceImplWrapper#notifyNotificationWithChannel(String, int, Notification, String)"
            android.util.Log.w(r6, r8)
            r10.writeNoException()
            return r2
        L_0x00c4:
            java.lang.String r8 = "Should NOT reach WebApkServiceImplWrapper#notificationPermissionEnabled()."
            android.util.Log.w(r6, r8)
            r10.writeNoException()
            r10.writeInt(r3)
            return r2
        L_0x00d0:
            r9.readString()
            r9.readInt()
            java.lang.String r8 = "Should NOT reach WebApkServiceImplWrapper#cancelNotification(String, int)."
            android.util.Log.w(r6, r8)
            r10.writeNoException()
            return r2
        L_0x00df:
            java.lang.String r8 = r9.readString()
            int r11 = r9.readInt()
            android.os.Parcelable$Creator r3 = android.app.Notification.CREATOR
            int r5 = r9.readInt()
            if (r5 == 0) goto L_0x00f3
            java.lang.Object r4 = r3.createFromParcel(r9)
        L_0x00f3:
            android.app.Notification r4 = (android.app.Notification) r4
            android.app.NotificationChannel r9 = new android.app.NotificationChannel
            r3 = 2131230728(0x7f080008, float:1.8077517E38)
            java.lang.String r3 = r0.getString(r3)
            r5 = 3
            java.lang.String r6 = "default_channel_id"
            r9.<init>(r6, r3, r5)
            java.lang.Object r1 = r0.getSystemService(r1)
            android.app.NotificationManager r1 = (android.app.NotificationManager) r1
            r1.createNotificationChannel(r9)
            android.app.Notification$Builder r9 = android.app.Notification.Builder.recoverBuilder(r0, r4)
            r9.setChannelId(r6)
            android.app.Notification r9 = r9.build()
            android.os.IBinder r0 = r7.b
            if (r0 != 0) goto L_0x011d
            goto L_0x0144
        L_0x011d:
            java.lang.Class r1 = r0.getClass()     // Catch:{ Exception -> 0x0140 }
            java.lang.String r3 = "notifyNotification"
            java.lang.Class<java.lang.String> r4 = java.lang.String.class
            java.lang.Class r5 = java.lang.Integer.TYPE     // Catch:{ Exception -> 0x0140 }
            java.lang.Class<android.app.Notification> r6 = android.app.Notification.class
            java.lang.Class[] r4 = new java.lang.Class[]{r4, r5, r6}     // Catch:{ Exception -> 0x0140 }
            java.lang.reflect.Method r1 = r1.getMethod(r3, r4)     // Catch:{ Exception -> 0x0140 }
            r1.setAccessible(r2)     // Catch:{ Exception -> 0x0140 }
            java.lang.Integer r11 = java.lang.Integer.valueOf(r11)     // Catch:{ Exception -> 0x0140 }
            java.lang.Object[] r8 = new java.lang.Object[]{r8, r11, r9}     // Catch:{ Exception -> 0x0140 }
            r1.invoke(r0, r8)     // Catch:{ Exception -> 0x0140 }
            goto L_0x0144
        L_0x0140:
            r8 = move-exception
            r8.printStackTrace()
        L_0x0144:
            r10.writeNoException()
            return r2
        L_0x0148:
            java.lang.String r8 = "Should NOT reach WebApkServiceImplWrapper#getSmallIconId()."
            android.util.Log.w(r6, r8)
            r10.writeNoException()
            r8 = -1
            r10.writeInt(r8)
            return r2
        L_0x0155:
            r10.writeString(r1)
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.A.b(int, android.os.Parcel, android.os.Parcel, int):boolean");
    }

    public final boolean onTransact(int i, Parcel parcel, Parcel parcel2, int i2) {
        int callingUid = Binder.getCallingUid();
        int i3 = this.a;
        if (i3 != callingUid) {
            throw new RemoteException("Unauthorized caller " + callingUid + " does not match expected host=" + i3);
        } else if (i == a("TRANSACTION_notifyNotification") || i == a("TRANSACTION_checkNotificationPermission") || i == a("TRANSACTION_requestNotificationPermission")) {
            return b(i, parcel, parcel2, i2);
        } else {
            Class<Parcel> cls = Parcel.class;
            IBinder iBinder = this.b;
            if (iBinder == null) {
                return false;
            }
            try {
                Class<?> cls2 = iBinder.getClass();
                Class cls3 = Integer.TYPE;
                Method method = cls2.getMethod("onTransact", new Class[]{cls3, cls, cls, cls3});
                method.setAccessible(true);
                return ((Boolean) method.invoke(iBinder, new Object[]{Integer.valueOf(i), parcel, parcel2, Integer.valueOf(i2)})).booleanValue();
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
    }

    public final IBinder asBinder() {
        return this;
    }
}
