package defpackage;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import android.util.Pair;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import org.chromium.webapk.shell_apk.h2o.SplashActivity;

/* renamed from: t  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class t extends AsyncTask {
    public final /* synthetic */ SplashActivity a;

    public t(SplashActivity splashActivity) {
        this.a = splashActivity;
    }

    public final Object doInBackground(Object[] objArr) {
        ByteArrayOutputStream byteArrayOutputStream;
        Bitmap.CompressFormat compressFormat;
        Void[] voidArr = (Void[]) objArr;
        SplashActivity splashActivity = this.a;
        try {
            byteArrayOutputStream = new ByteArrayOutputStream();
            if (splashActivity.c.getWidth() * splashActivity.c.getHeight() <= 1048576) {
                compressFormat = Bitmap.CompressFormat.PNG;
            } else {
                compressFormat = Bitmap.CompressFormat.JPEG;
            }
            splashActivity.c.compress(compressFormat, 100, byteArrayOutputStream);
            Pair create = Pair.create(byteArrayOutputStream.toByteArray(), compressFormat);
            byteArrayOutputStream.close();
            return create;
        } catch (IOException unused) {
            return null;
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
    }

    public final void onPostExecute(Object obj) {
        Bitmap.CompressFormat compressFormat;
        Pair pair = (Pair) obj;
        SplashActivity splashActivity = this.a;
        byte[] bArr = null;
        splashActivity.a = null;
        if (pair != null) {
            bArr = (byte[]) pair.first;
        }
        if (pair == null) {
            compressFormat = Bitmap.CompressFormat.PNG;
        } else {
            compressFormat = (Bitmap.CompressFormat) pair.second;
        }
        splashActivity.a(bArr, compressFormat);
    }
}
