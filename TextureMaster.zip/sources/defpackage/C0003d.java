package defpackage;

/* renamed from: d  reason: default package and case insensitive filesystem */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract class C0003d {
    /* JADX WARNING: Removed duplicated region for block: B:21:0x00ac  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static void a(android.app.Activity r8, defpackage.e r9, android.os.Bundle r10, int r11, boolean r12) {
        /*
            android.content.Context r0 = r8.getApplicationContext()
            int r1 = org.chromium.webapk.shell_apk.ManageDataLauncherActivity.c
            java.lang.Class<android.content.pm.ShortcutManager> r1 = android.content.pm.ShortcutManager.class
            java.lang.Object r1 = r0.getSystemService(r1)
            android.content.pm.ShortcutManager r1 = (android.content.pm.ShortcutManager) r1
            f r2 = r9.b
            java.lang.String r2 = r2.a
            boolean r2 = org.chromium.webapk.shell_apk.ManageDataLauncherActivity.b(r0, r2)
            java.lang.String r3 = r9.e
            f r4 = r9.b
            java.lang.String r5 = "android.support.customtabs.action.SITE_SETTINGS_SHORTCUT"
            if (r2 != 0) goto L_0x0026
            java.util.List r0 = java.util.Collections.singletonList(r5)
            r1.removeDynamicShortcuts(r0)
            goto L_0x0072
        L_0x0026:
            java.lang.String r2 = r4.a
            android.content.Intent r6 = new android.content.Intent
            java.lang.Class<org.chromium.webapk.shell_apk.ManageDataLauncherActivity> r7 = org.chromium.webapk.shell_apk.ManageDataLauncherActivity.class
            r6.<init>(r0, r7)
            java.lang.String r7 = "android.support.customtabs.action.ACTION_MANAGE_TRUSTED_WEB_ACTIVITY_DATA"
            r6.setAction(r7)
            java.lang.String r7 = "SITE_SETTINGS_URL"
            r6.putExtra(r7, r3)
            java.lang.String r7 = "PROVIDER_PACKAGE"
            r6.putExtra(r7, r2)
            android.content.pm.ShortcutInfo$Builder r2 = new android.content.pm.ShortcutInfo$Builder
            r2.<init>(r0, r5)
            r5 = 2131230739(0x7f080013, float:1.807754E38)
            java.lang.String r5 = r0.getString(r5)
            android.content.pm.ShortcutInfo$Builder r2 = r2.setShortLabel(r5)
            r5 = 2131230738(0x7f080012, float:1.8077537E38)
            java.lang.String r5 = r0.getString(r5)
            android.content.pm.ShortcutInfo$Builder r2 = r2.setLongLabel(r5)
            r5 = 2131034112(0x7f050000, float:1.7678732E38)
            android.graphics.drawable.Icon r0 = android.graphics.drawable.Icon.createWithResource(r0, r5)
            android.content.pm.ShortcutInfo$Builder r0 = r2.setIcon(r0)
            android.content.pm.ShortcutInfo$Builder r0 = r0.setIntent(r6)
            android.content.pm.ShortcutInfo r0 = r0.build()
            java.util.List r0 = java.util.Collections.singletonList(r0)
            r1.addDynamicShortcuts(r0)
        L_0x0072:
            android.content.Context r0 = r8.getApplicationContext()
            java.lang.String r1 = r4.a
            java.util.HashSet r2 = defpackage.g.a
            boolean r2 = android.text.TextUtils.isEmpty(r1)
            r5 = 0
            if (r2 == 0) goto L_0x0083
            r0 = r5
            goto L_0x00b1
        L_0x0083:
            android.os.Bundle r2 = defpackage.D.d(r0)
            r6 = 0
            if (r2 != 0) goto L_0x008c
            r2 = r6
            goto L_0x0092
        L_0x008c:
            java.lang.String r7 = "org.chromium.webapk.shell_apk.runtimeHost"
            java.lang.String r2 = r2.getString(r7)
        L_0x0092:
            boolean r7 = android.text.TextUtils.isEmpty(r2)
            if (r7 != 0) goto L_0x00ad
            android.content.pm.PackageManager r0 = r0.getPackageManager()
            boolean r7 = android.text.TextUtils.isEmpty(r2)
            if (r7 == 0) goto L_0x00a4
        L_0x00a2:
            r0 = r5
            goto L_0x00aa
        L_0x00a4:
            android.content.pm.ApplicationInfo r0 = r0.getApplicationInfo(r2, r5)     // Catch:{ NameNotFoundException -> 0x00a2 }
            boolean r0 = r0.enabled
        L_0x00aa:
            if (r0 == 0) goto L_0x00ad
            r6 = r2
        L_0x00ad:
            boolean r0 = android.text.TextUtils.equals(r1, r6)
        L_0x00b1:
            java.lang.String r1 = r4.a
            android.content.ComponentName r2 = r4.b
            android.net.Uri r4 = android.net.Uri.parse(r3)
            java.lang.String r6 = "android.intent.action.VIEW"
            if (r0 == 0) goto L_0x00c8
            android.content.Intent r0 = new android.content.Intent
            r0.<init>()
            java.lang.String r4 = "com.google.android.apps.chrome.webapps.WebappManager.ACTION_START_WEBAPP"
            r0.setAction(r4)
            goto L_0x00cd
        L_0x00c8:
            android.content.Intent r0 = new android.content.Intent
            r0.<init>(r6, r4)
        L_0x00cd:
            if (r2 == 0) goto L_0x00ef
            android.content.Intent r1 = new android.content.Intent
            r1.<init>()
            android.content.Intent r1 = r1.setAction(r6)
            java.lang.String r4 = "android.intent.category.BROWSABLE"
            android.content.Intent r1 = r1.addCategory(r4)
            java.lang.String r4 = "http://"
            android.net.Uri r4 = android.net.Uri.parse(r4)
            android.content.Intent r1 = r1.setData(r4)
            r0.setSelector(r1)
            r0.setComponent(r2)
            goto L_0x00f2
        L_0x00ef:
            r0.setPackage(r1)
        L_0x00f2:
            r0.setFlags(r11)
            android.content.Intent r11 = r9.d
            android.os.Bundle r11 = r11.getExtras()
            if (r11 == 0) goto L_0x0100
            r0.putExtras(r11)
        L_0x0100:
            java.lang.String r11 = "org.chromium.webapk.relaunch"
            r0.removeExtra(r11)
            java.lang.String r11 = "org.chromium.chrome.browser.webapp_url"
            android.content.Intent r11 = r0.putExtra(r11, r3)
            java.lang.String r1 = "org.chromium.chrome.browser.webapp_source"
            int r2 = r9.f
            android.content.Intent r11 = r11.putExtra(r1, r2)
            java.lang.String r1 = "org.chromium.chrome.browser.webapk_package_name"
            java.lang.String r2 = r8.getPackageName()
            android.content.Intent r11 = r11.putExtra(r1, r2)
            java.lang.String r1 = "org.chromium.webapk.selected_share_target_activity_class_name"
            java.lang.String r2 = r9.j
            android.content.Intent r11 = r11.putExtra(r1, r2)
            java.lang.String r1 = "org.chromium.chrome.browser.webapk_force_navigation"
            boolean r2 = r9.g
            r11.putExtra(r1, r2)
            if (r10 == 0) goto L_0x0131
            r0.putExtras(r10)
        L_0x0131:
            boolean r10 = r9.c
            r1 = 0
            if (r10 != 0) goto L_0x0142
            long r10 = r9.h
            int r3 = (r10 > r1 ? 1 : (r10 == r1 ? 0 : -1))
            if (r3 < 0) goto L_0x0142
            java.lang.String r3 = "org.chromium.chrome.browser.webapk_launch_time"
            r0.putExtra(r3, r10)
        L_0x0142:
            long r9 = r9.i
            int r11 = (r9 > r1 ? 1 : (r9 == r1 ? 0 : -1))
            if (r11 < 0) goto L_0x014d
            java.lang.String r11 = "org.chromium.webapk.new_style_splash_shown_time"
            r0.putExtra(r11, r9)
        L_0x014d:
            if (r12 == 0) goto L_0x0153
            r8.startActivityForResult(r0, r5)     // Catch:{ ActivityNotFoundException -> 0x0157 }
            goto L_0x0162
        L_0x0153:
            r8.startActivity(r0)     // Catch:{ ActivityNotFoundException -> 0x0157 }
            goto L_0x0162
        L_0x0157:
            r8 = move-exception
            java.lang.String r9 = "cr_HostBrowserLauncher"
            java.lang.String r10 = "Unable to launch browser in WebAPK mode."
            android.util.Log.w(r9, r10)
            r8.printStackTrace()
        L_0x0162:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.C0003d.a(android.app.Activity, e, android.os.Bundle, int, boolean):void");
    }
}
