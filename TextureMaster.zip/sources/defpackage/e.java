package defpackage;

import android.content.Intent;

/* renamed from: e  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class e {
    public boolean a;
    public f b;
    public boolean c;
    public Intent d;
    public String e;
    public int f;
    public boolean g;
    public long h;
    public long i;
    public String j;

    /* JADX WARNING: type inference failed for: r2v2, types: [e, java.lang.Object] */
    /* JADX WARNING: Removed duplicated region for block: B:21:0x0064  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static defpackage.e a(android.content.Context r14, android.content.Intent r15, defpackage.f r16, boolean r17, long r18, long r20) {
        /*
            android.os.Bundle r1 = defpackage.D.d(r14)
            r2 = 0
            if (r1 != 0) goto L_0x0009
            goto L_0x01b6
        L_0x0009:
            java.lang.String r3 = "org.chromium.chrome.browser.webapk_launch_time"
            r4 = -1
            long r3 = r15.getLongExtra(r3, r4)
            r5 = 0
            int r5 = (r3 > r5 ? 1 : (r3 == r5 ? 0 : -1))
            if (r5 <= 0) goto L_0x0018
            goto L_0x001a
        L_0x0018:
            r3 = r18
        L_0x001a:
            java.lang.String r5 = "org.chromium.webapk.selected_share_target_activity_class_name"
            java.lang.String r5 = r15.getStringExtra(r5)
            java.lang.String r6 = "android.intent.action.SEND"
            java.lang.String r7 = r15.getAction()
            boolean r6 = r6.equals(r7)
            if (r6 != 0) goto L_0x0038
            java.lang.String r6 = "android.intent.action.SEND_MULTIPLE"
            java.lang.String r7 = r15.getAction()
            boolean r6 = r6.equals(r7)
            if (r6 == 0) goto L_0x0040
        L_0x0038:
            android.content.ComponentName r5 = r15.getComponent()
            java.lang.String r5 = r5.getClassName()
        L_0x0040:
            r6 = 1
            java.lang.String r7 = "org.chromium.webapk.shell_apk.startUrl"
            r8 = 0
            if (r5 == 0) goto L_0x0125
            android.content.ComponentName r9 = new android.content.ComponentName
            java.lang.String r10 = r14.getPackageName()
            r9.<init>(r10, r5)
            android.content.pm.PackageManager r14 = r14.getPackageManager()     // Catch:{ NameNotFoundException -> 0x005b }
            r10 = 128(0x80, float:1.794E-43)
            android.content.pm.ActivityInfo r14 = r14.getActivityInfo(r9, r10)     // Catch:{ NameNotFoundException -> 0x005b }
            if (r14 != 0) goto L_0x005d
        L_0x005b:
            r14 = r2
            goto L_0x005f
        L_0x005d:
            android.os.Bundle r14 = r14.metaData
        L_0x005f:
            if (r14 != 0) goto L_0x0064
        L_0x0061:
            r14 = r2
            goto L_0x0122
        L_0x0064:
            java.lang.String r9 = "org.chromium.webapk.shell_apk.shareMethod"
            java.lang.String r9 = r14.getString(r9)
            boolean r10 = android.text.TextUtils.isEmpty(r9)
            if (r10 == 0) goto L_0x0072
            r9 = r8
            goto L_0x007e
        L_0x0072:
            java.util.Locale r10 = java.util.Locale.ENGLISH
            java.lang.String r9 = r9.toUpperCase(r10)
            java.lang.String r10 = "POST"
            boolean r9 = r10.equals(r9)
        L_0x007e:
            java.lang.String r10 = "org.chromium.webapk.shell_apk.shareAction"
            if (r9 == 0) goto L_0x0088
            java.lang.String r14 = r14.getString(r10)
            goto L_0x0122
        L_0x0088:
            java.lang.String r9 = r14.getString(r10)
            boolean r10 = android.text.TextUtils.isEmpty(r9)
            if (r10 == 0) goto L_0x0093
            goto L_0x0061
        L_0x0093:
            java.util.ArrayList r10 = new java.util.ArrayList
            r10.<init>()
            android.util.Pair r11 = new android.util.Pair
            java.lang.String r12 = "org.chromium.webapk.shell_apk.shareParamTitle"
            java.lang.String r12 = r14.getString(r12)
            java.lang.String r13 = "android.intent.extra.SUBJECT"
            java.lang.String r13 = r15.getStringExtra(r13)
            r11.<init>(r12, r13)
            r10.add(r11)
            android.util.Pair r11 = new android.util.Pair
            java.lang.String r12 = "org.chromium.webapk.shell_apk.shareParamText"
            java.lang.String r14 = r14.getString(r12)
            java.lang.String r12 = "android.intent.extra.TEXT"
            java.lang.String r12 = r15.getStringExtra(r12)
            r11.<init>(r14, r12)
            r10.add(r11)
            android.net.Uri$Builder r14 = new android.net.Uri$Builder
            r14.<init>()
            int r11 = r10.size()
        L_0x00c9:
            if (r8 >= r11) goto L_0x00f3
            java.lang.Object r12 = r10.get(r8)
            int r8 = r8 + 1
            android.util.Pair r12 = (android.util.Pair) r12
            java.lang.Object r13 = r12.first
            java.lang.CharSequence r13 = (java.lang.CharSequence) r13
            boolean r13 = android.text.TextUtils.isEmpty(r13)
            if (r13 != 0) goto L_0x00c9
            java.lang.Object r13 = r12.second
            java.lang.CharSequence r13 = (java.lang.CharSequence) r13
            boolean r13 = android.text.TextUtils.isEmpty(r13)
            if (r13 != 0) goto L_0x00c9
            java.lang.Object r13 = r12.first
            java.lang.String r13 = (java.lang.String) r13
            java.lang.Object r12 = r12.second
            java.lang.String r12 = (java.lang.String) r12
            r14.appendQueryParameter(r13, r12)
            goto L_0x00c9
        L_0x00f3:
            android.net.Uri r8 = android.net.Uri.parse(r9)
            android.net.Uri$Builder r8 = r8.buildUpon()
            android.net.Uri r14 = r14.build()
            java.lang.String r14 = r14.toString()
            boolean r10 = android.text.TextUtils.isEmpty(r14)
            if (r10 == 0) goto L_0x010b
            r14 = r9
            goto L_0x0122
        L_0x010b:
            java.lang.String r9 = "%20"
            java.lang.String r10 = "+"
            java.lang.String r14 = r14.replace(r9, r10)
            java.lang.String r14 = r14.substring(r6)
            r8.encodedQuery(r14)
            android.net.Uri r14 = r8.build()
            java.lang.String r14 = r14.toString()
        L_0x0122:
            r8 = 13
            goto L_0x0147
        L_0x0125:
            java.lang.String r14 = r15.getDataString()
            boolean r14 = android.text.TextUtils.isEmpty(r14)
            if (r14 != 0) goto L_0x0142
            java.lang.String r14 = r15.getDataString()
            java.lang.String r8 = "org.chromium.chrome.browser.webapp_source"
            r9 = 9
            int r8 = r15.getIntExtra(r8, r9)
            java.lang.String r9 = "org.chromium.chrome.browser.webapk_force_navigation"
            boolean r6 = r15.getBooleanExtra(r9, r6)
            goto L_0x0147
        L_0x0142:
            java.lang.String r14 = r1.getString(r7)
            r6 = r8
        L_0x0147:
            if (r14 != 0) goto L_0x014a
            goto L_0x01b6
        L_0x014a:
            java.lang.String r7 = r1.getString(r7)
            java.lang.String r9 = "org.chromium.webapk.shell_apk.loggedIntentUrlParam"
            java.lang.String r9 = r1.getString(r9)
            boolean r10 = android.text.TextUtils.isEmpty(r9)
            if (r10 == 0) goto L_0x015b
            goto L_0x017f
        L_0x015b:
            boolean r10 = r14.startsWith(r7)
            if (r10 == 0) goto L_0x0170
            android.net.Uri r10 = android.net.Uri.parse(r14)
            java.lang.String r10 = r10.getQueryParameter(r9)
            boolean r10 = android.text.TextUtils.isEmpty(r10)
            if (r10 != 0) goto L_0x0170
            goto L_0x017f
        L_0x0170:
            android.net.Uri r7 = android.net.Uri.parse(r7)
            android.net.Uri$Builder r7 = r7.buildUpon()
            r7.appendQueryParameter(r9, r14)
            java.lang.String r14 = r7.toString()
        L_0x017f:
            if (r14 == 0) goto L_0x01b6
            java.lang.String r7 = "http:"
            boolean r7 = r14.startsWith(r7)
            if (r7 != 0) goto L_0x0191
            java.lang.String r7 = "https:"
            boolean r7 = r14.startsWith(r7)
            if (r7 == 0) goto L_0x01b6
        L_0x0191:
            java.lang.String r2 = "org.chromium.webapk.shell_apk.isNewStyleWebApk"
            boolean r1 = r1.getBoolean(r2)
            e r2 = new e
            r2.<init>()
            r2.a = r1
            r1 = r16
            r2.b = r1
            r1 = r17
            r2.c = r1
            r2.d = r15
            r2.e = r14
            r2.f = r8
            r2.g = r6
            r2.h = r3
            r0 = r20
            r2.i = r0
            r2.j = r5
        L_0x01b6:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.e.a(android.content.Context, android.content.Intent, f, boolean, long, long):e");
    }
}
