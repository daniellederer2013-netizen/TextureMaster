package defpackage;

import android.content.DialogInterface;

/* renamed from: k  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class k implements DialogInterface.OnDismissListener {
    public final /* synthetic */ l a;
    public final /* synthetic */ m b;

    public k(l lVar, m mVar) {
        this.a = lVar;
        this.b = mVar;
    }

    public final void onDismiss(DialogInterface dialogInterface) {
        if (!this.a.a) {
            this.b.a.a((f) null, true);
        }
    }
}
