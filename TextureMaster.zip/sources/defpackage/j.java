package defpackage;

import android.content.DialogInterface;

/* renamed from: j  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class j implements DialogInterface.OnClickListener {
    public final void onClick(DialogInterface dialogInterface, int i) {
        dialogInterface.cancel();
    }
}
