package defpackage;

import android.os.Handler;

/* renamed from: v  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class v {
    public byte[] a;
    public Handler b;
}
