package defpackage;

/* renamed from: w  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract class w {
    /* JADX WARNING: Removed duplicated region for block: B:10:0x0024  */
    /* JADX WARNING: Removed duplicated region for block: B:18:0x004f  */
    /* JADX WARNING: Removed duplicated region for block: B:23:0x0085  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x009f  */
    /* JADX WARNING: Removed duplicated region for block: B:9:0x001c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static android.widget.FrameLayout a(android.content.Context r11) {
        /*
            android.content.res.Resources r0 = r11.getResources()
            r1 = 2131034119(0x7f050007, float:1.7678747E38)
            r2 = 0
            android.graphics.drawable.Drawable r1 = r0.getDrawable(r1, r2)     // Catch:{ NotFoundException -> 0x0015 }
            if (r1 == 0) goto L_0x0015
            android.graphics.drawable.BitmapDrawable r1 = (android.graphics.drawable.BitmapDrawable) r1     // Catch:{ NotFoundException -> 0x0015 }
            android.graphics.Bitmap r1 = r1.getBitmap()     // Catch:{ NotFoundException -> 0x0015 }
            goto L_0x0016
        L_0x0015:
            r1 = r2
        L_0x0016:
            boolean r3 = defpackage.D.b(r11)
            if (r3 == 0) goto L_0x0024
            r3 = 2130903041(0x7f030001, float:1.7412889E38)
            int r3 = r0.getColor(r3, r2)
            goto L_0x002a
        L_0x0024:
            r3 = 2130903040(0x7f030000, float:1.7412887E38)
            int r3 = r0.getColor(r3, r2)
        L_0x002a:
            android.widget.FrameLayout r4 = new android.widget.FrameLayout
            r4.<init>(r11)
            android.content.res.Resources r5 = r11.getResources()     // Catch:{ NotFoundException -> 0x003a }
            r6 = 2130837504(0x7f020000, float:1.7279964E38)
            boolean r5 = r5.getBoolean(r6)     // Catch:{ NotFoundException -> 0x003a }
            goto L_0x003b
        L_0x003a:
            r5 = 0
        L_0x003b:
            r6 = 2131230726(0x7f080006, float:1.8077513E38)
            java.lang.String r0 = r0.getString(r6)
            boolean r6 = defpackage.D.e(r3)
            android.content.res.Resources r7 = r11.getResources()
            r8 = 2131099651(0x7f060003, float:1.7811661E38)
            if (r1 == 0) goto L_0x006c
            android.util.DisplayMetrics r9 = r7.getDisplayMetrics()
            int r10 = r1.getScaledWidth(r9)
            int r9 = r1.getScaledHeight(r9)
            int r9 = java.lang.Math.min(r10, r9)
            r10 = 2130968585(0x7f040009, float:1.7545828E38)
            int r7 = r7.getDimensionPixelSize(r10)
            if (r9 >= r7) goto L_0x0069
            goto L_0x006c
        L_0x0069:
            r8 = 2131099650(0x7f060002, float:1.781166E38)
        L_0x006c:
            android.view.LayoutInflater r7 = android.view.LayoutInflater.from(r11)
            r9 = 1
            android.view.View r7 = r7.inflate(r8, r4, r9)
            android.view.ViewGroup r7 = (android.view.ViewGroup) r7
            r8 = 2130771974(0x7f010006, float:1.7147053E38)
            android.view.View r8 = r7.findViewById(r8)
            android.widget.TextView r8 = (android.widget.TextView) r8
            r8.setText(r0)
            if (r6 == 0) goto L_0x0093
            android.content.res.Resources r11 = r11.getResources()
            r0 = 2130903047(0x7f030007, float:1.74129E38)
            int r11 = r11.getColor(r0, r2)
            r8.setTextColor(r11)
        L_0x0093:
            r11 = 2130771972(0x7f010004, float:1.714705E38)
            android.view.View r11 = r7.findViewById(r11)
            android.widget.ImageView r11 = (android.widget.ImageView) r11
            if (r11 != 0) goto L_0x009f
            goto L_0x00ac
        L_0x009f:
            if (r5 == 0) goto L_0x00a9
            android.graphics.drawable.Icon r0 = android.graphics.drawable.Icon.createWithAdaptiveBitmap(r1)
            r11.setImageIcon(r0)
            goto L_0x00ac
        L_0x00a9:
            r11.setImageBitmap(r1)
        L_0x00ac:
            r4.setBackgroundColor(r3)
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.w.a(android.content.Context):android.widget.FrameLayout");
    }
}
