package defpackage;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import org.chromium.webapk.a49e07bcf15ff6314_v2.R;

/* renamed from: o  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class o {
    public final Context a;
    public final Activity b;

    public o(Activity activity) {
        this.b = activity;
        this.a = activity.getApplicationContext();
    }

    /* JADX WARNING: type inference failed for: r10v13, types: [java.lang.Object, l] */
    /* JADX WARNING: type inference failed for: r2v9, types: [android.content.DialogInterface$OnClickListener, java.lang.Object] */
    public final void a(n nVar) {
        Context context = this.a;
        Bundle d = D.d(context);
        if (d == null) {
            nVar.a((f) null, false);
            return;
        }
        String packageName = context.getPackageName();
        Log.v("cr_LaunchHostBrowserSelector", "Package name of the WebAPK:" + packageName);
        f a2 = g.a(context);
        if (a2 == null || TextUtils.isEmpty(a2.a)) {
            String string = d.getString("org.chromium.webapk.shell_apk.runtimeHost");
            String string2 = d.getString("org.chromium.webapk.shell_apk.runtimeHostApplicationName");
            if (TextUtils.isEmpty(string)) {
                string = "com.android.chrome";
                string2 = "Google Chrome";
            }
            m mVar = new m(this, nVar);
            String string3 = context.getString(R.string.name);
            Activity activity = this.b;
            View inflate = LayoutInflater.from(activity).inflate(R.layout.host_browser_list_item, (ViewGroup) null);
            TextView textView = new TextView(activity);
            textView.setText(activity.getString(R.string.install_host_browser_dialog_title, new Object[]{string3}));
            Resources resources = activity.getResources();
            textView.setTextColor(resources.getColor(R.color.webapk_black_alpha_87, (Resources.Theme) null));
            textView.setTextSize(0, resources.getDimension(R.dimen.headline_size_medium));
            int dimensionPixelSize = resources.getDimensionPixelSize(R.dimen.dialog_content_padding);
            textView.setPaddingRelative(dimensionPixelSize, dimensionPixelSize, dimensionPixelSize, resources.getDimensionPixelSize(R.dimen.title_bottom_padding));
            inflate.setPaddingRelative(dimensionPixelSize, resources.getDimensionPixelSize(R.dimen.dialog_content_top_padding), dimensionPixelSize, dimensionPixelSize);
            ((ImageView) inflate.findViewById(R.id.browser_icon)).setImageResource(R.drawable.last_resort_runtime_host_logo);
            TextView textView2 = (TextView) inflate.findViewById(R.id.browser_name);
            textView2.setText(string2);
            textView2.setPaddingRelative(activity.getResources().getDimensionPixelSize(R.dimen.list_column_padding), 0, 0, 0);
            ? obj = new Object();
            AlertDialog.Builder builder = new AlertDialog.Builder(new ContextThemeWrapper(activity, 16974130));
            builder.setCustomTitle(textView).setView(inflate).setNegativeButton(R.string.choose_host_browser_dialog_quit, new Object()).setPositiveButton(R.string.install_host_browser_dialog_install_button, new i(obj, mVar, string));
            AlertDialog create = builder.create();
            create.setOnDismissListener(new k(obj, mVar));
            create.show();
            return;
        }
        nVar.a(a2, false);
    }
}
