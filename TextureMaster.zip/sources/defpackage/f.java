package defpackage;

import android.content.ComponentName;

/* renamed from: f  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class f {
    public String a;
    public ComponentName b;
}
