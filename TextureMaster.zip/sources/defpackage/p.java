package defpackage;

/* renamed from: p  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class p {
    public final q a;
    public boolean b;
    public boolean c;
    public boolean d;
    public boolean e;

    public p(q qVar) {
        this.a = qVar;
    }

    public final void a() {
        if (this.d && this.b && this.c && !this.e) {
            this.e = true;
            this.a.run();
        }
    }
}
