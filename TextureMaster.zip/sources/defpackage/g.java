package defpackage;

import java.util.Arrays;
import java.util.HashSet;

/* renamed from: g  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract class g {
    public static final HashSet a = new HashSet(Arrays.asList(new String[]{"com.google.android.apps.chrome", "com.android.chrome", "com.chrome.beta", "com.chrome.dev", "com.chrome.canary", "org.chromium.chrome", "org.chromium.chrome.tests", "org.chromium.arc.intent_helper", "org.chromium.arc.webapk"}));

    /* JADX WARNING: type inference failed for: r5v2, types: [f, java.lang.Object] */
    /* JADX WARNING: type inference failed for: r5v4, types: [f, java.lang.Object] */
    /* JADX WARNING: Code restructure failed: missing block: B:13:0x0028, code lost:
        if (r2 == false) goto L_0x002b;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static defpackage.f a(android.content.Context r5) {
        /*
            android.os.Bundle r0 = defpackage.D.d(r5)
            r1 = 0
            if (r0 != 0) goto L_0x0009
            r0 = r1
            goto L_0x000f
        L_0x0009:
            java.lang.String r2 = "org.chromium.webapk.shell_apk.runtimeHost"
            java.lang.String r0 = r0.getString(r2)
        L_0x000f:
            boolean r2 = android.text.TextUtils.isEmpty(r0)
            r3 = 0
            if (r2 != 0) goto L_0x002b
            android.content.pm.PackageManager r2 = r5.getPackageManager()
            boolean r4 = android.text.TextUtils.isEmpty(r0)
            if (r4 == 0) goto L_0x0022
        L_0x0020:
            r2 = r3
            goto L_0x0028
        L_0x0022:
            android.content.pm.ApplicationInfo r2 = r2.getApplicationInfo(r0, r3)     // Catch:{ NameNotFoundException -> 0x0020 }
            boolean r2 = r2.enabled
        L_0x0028:
            if (r2 == 0) goto L_0x002b
            goto L_0x002c
        L_0x002b:
            r0 = r1
        L_0x002c:
            boolean r2 = android.text.TextUtils.isEmpty(r0)
            if (r2 != 0) goto L_0x003c
            f r5 = new f
            r5.<init>()
            r5.a = r0
            r5.b = r1
            return r5
        L_0x003c:
            android.content.pm.PackageManager r5 = r5.getPackageManager()
            android.content.Intent r0 = new android.content.Intent
            r0.<init>()
            java.lang.String r2 = "android.intent.action.VIEW"
            android.content.Intent r0 = r0.setAction(r2)
            java.lang.String r2 = "android.intent.category.BROWSABLE"
            android.content.Intent r0 = r0.addCategory(r2)
            java.lang.String r2 = "http://"
            android.net.Uri r2 = android.net.Uri.parse(r2)
            android.content.Intent r0 = r0.setData(r2)
            r2 = 65536(0x10000, float:9.18355E-41)
            android.content.pm.ResolveInfo r0 = r5.resolveActivity(r0, r2)
            if (r0 == 0) goto L_0x0073
            android.content.pm.ActivityInfo r2 = r0.activityInfo
            if (r2 == 0) goto L_0x0073
            android.content.ComponentName r2 = new android.content.ComponentName
            android.content.pm.ActivityInfo r0 = r0.activityInfo
            java.lang.String r4 = r0.packageName
            java.lang.String r0 = r0.name
            r2.<init>(r4, r0)
            goto L_0x0074
        L_0x0073:
            r2 = r1
        L_0x0074:
            if (r2 == 0) goto L_0x00a1
            java.lang.String r0 = r2.getPackageName()
            boolean r0 = android.text.TextUtils.isEmpty(r0)
            if (r0 != 0) goto L_0x00a1
            java.lang.String r0 = r2.getPackageName()
            boolean r4 = android.text.TextUtils.isEmpty(r0)
            if (r4 == 0) goto L_0x008b
            goto L_0x0091
        L_0x008b:
            android.content.pm.ApplicationInfo r5 = r5.getApplicationInfo(r0, r3)     // Catch:{ NameNotFoundException -> 0x0091 }
            boolean r3 = r5.enabled
        L_0x0091:
            if (r3 == 0) goto L_0x00a1
            f r5 = new f
            r5.<init>()
            java.lang.String r0 = r2.getPackageName()
            r5.a = r0
            r5.b = r2
            return r5
        L_0x00a1:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: defpackage.g.a(android.content.Context):f");
    }

    public static boolean b(e eVar) {
        if (!eVar.a) {
            return false;
        }
        f fVar = eVar.b;
        if (fVar.a.equals("org.chromium.arc.intent_helper") || fVar.a.equals("org.chromium.arc.webapk")) {
            return false;
        }
        return true;
    }
}
