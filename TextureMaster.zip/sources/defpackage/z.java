package defpackage;

import android.os.Bundle;

/* renamed from: z  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract class z {
    public static long a(Bundle bundle, String str, long j) {
        String string = bundle.getString(str);
        if (string != null && string.endsWith("L")) {
            try {
                return Long.parseLong(string.substring(0, string.length() - 1));
            } catch (NumberFormatException unused) {
            }
        }
        return j;
    }
}
