package defpackage;

import android.graphics.Bitmap;
import android.os.AsyncTask;
import org.chromium.webapk.shell_apk.h2o.SplashActivity;

/* renamed from: q  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final /* synthetic */ class q implements Runnable {
    public final /* synthetic */ SplashActivity a;

    public /* synthetic */ q(SplashActivity splashActivity) {
        this.a = splashActivity;
    }

    public final void run() {
        SplashActivity splashActivity = this.a;
        if (splashActivity.c == null) {
            splashActivity.a((byte[]) null, Bitmap.CompressFormat.PNG);
        } else {
            splashActivity.a = new t(splashActivity).executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new Void[0]);
        }
    }
}
