package defpackage;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Bundle;
import org.chromium.webapk.shell_apk.h2o.H2OMainActivity;
import org.chromium.webapk.shell_apk.h2o.H2OOpaqueMainActivity;
import org.chromium.webapk.shell_apk.h2o.SplashActivity;

/* renamed from: r  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class r implements n {
    public final /* synthetic */ long a;
    public final /* synthetic */ SplashActivity b;

    public r(SplashActivity splashActivity, long j) {
        this.a = j;
        this.b = splashActivity;
    }

    public final void a(f fVar, boolean z) {
        SplashActivity splashActivity = this.b;
        if (fVar == null) {
            splashActivity.finish();
            return;
        }
        e a2 = e.a(splashActivity, splashActivity.getIntent(), fVar, z, -1, this.a);
        int i = SplashActivity.g;
        if (a2 == null) {
            splashActivity.finish();
            return;
        }
        Context applicationContext = splashActivity.getApplicationContext();
        if (!g.b(a2)) {
            C0003d.a(splashActivity, a2, (Bundle) null, 268435456, false);
            ComponentName componentName = new ComponentName(applicationContext, H2OMainActivity.class);
            ComponentName componentName2 = new ComponentName(applicationContext, H2OOpaqueMainActivity.class);
            B.a(applicationContext).edit().commit();
            PackageManager packageManager = applicationContext.getPackageManager();
            packageManager.setComponentEnabledSetting(componentName, 1, 1);
            packageManager.setComponentEnabledSetting(componentName2, 2, 0);
            splashActivity.finish();
            return;
        }
        splashActivity.d = a2;
        p pVar = splashActivity.f;
        pVar.d = true;
        pVar.a();
    }
}
