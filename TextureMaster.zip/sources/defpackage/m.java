package defpackage;

/* renamed from: m  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class m {
    public final /* synthetic */ n a;
    public final /* synthetic */ o b;

    public m(o oVar, n nVar) {
        this.a = nVar;
        this.b = oVar;
    }
}
