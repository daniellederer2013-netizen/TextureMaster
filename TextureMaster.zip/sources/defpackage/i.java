package defpackage;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

/* renamed from: i  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class i implements DialogInterface.OnClickListener {
    public final /* synthetic */ l a;
    public final /* synthetic */ m b;
    public final /* synthetic */ String c;

    public i(l lVar, m mVar, String str) {
        this.a = lVar;
        this.b = mVar;
        this.c = str;
    }

    public final void onClick(DialogInterface dialogInterface, int i) {
        this.a.a = true;
        String str = this.c;
        m mVar = this.b;
        o oVar = mVar.b;
        oVar.getClass();
        try {
            Activity activity = oVar.b;
            Intent intent = new Intent("android.intent.action.VIEW", Uri.parse("market://details?id=" + str));
            intent.addFlags(268435456);
            activity.startActivity(intent);
        } catch (ActivityNotFoundException unused) {
        }
        mVar.a.a((f) null, true);
    }
}
