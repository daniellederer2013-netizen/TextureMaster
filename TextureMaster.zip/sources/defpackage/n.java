package defpackage;

/* renamed from: n  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public interface n {
    void a(f fVar, boolean z);
}
