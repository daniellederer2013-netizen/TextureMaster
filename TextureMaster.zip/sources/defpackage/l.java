package defpackage;

/* renamed from: l  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class l {
    public boolean a;
}
