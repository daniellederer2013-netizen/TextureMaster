package defpackage;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import org.chromium.webapk.shell_apk.h2o.SplashActivity;

/* renamed from: D  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract class D {
    public static void a(Context context, e eVar) {
        if (eVar.j != null) {
            Intent intent = eVar.d;
            ArrayList parcelableArrayListExtra = intent.getParcelableArrayListExtra("android.intent.extra.STREAM");
            if (parcelableArrayListExtra == null) {
                parcelableArrayListExtra = new ArrayList();
                Uri uri = (Uri) intent.getParcelableExtra("android.intent.extra.STREAM");
                if (uri != null) {
                    parcelableArrayListExtra.add(uri);
                }
            }
            int size = parcelableArrayListExtra.size();
            int i = 0;
            while (i < size) {
                Object obj = parcelableArrayListExtra.get(i);
                i++;
                context.grantUriPermission(eVar.b.a, (Uri) obj, 1);
            }
        }
    }

    public static boolean b(Context context) {
        if ((context.getResources().getConfiguration().uiMode & 48) == 32) {
            return true;
        }
        return false;
    }

    public static boolean c(SplashActivity splashActivity) {
        try {
            return splashActivity.getApplicationContext().getPackageManager().hasSystemFeature("android.hardware.type.automotive");
        } catch (SecurityException e) {
            Log.e("cr_WebApkUtils", "Unable to query for Automotive system feature", e);
            return false;
        }
    }

    public static Bundle d(Context context) {
        try {
            return context.getPackageManager().getApplicationInfo(context.getPackageName(), 128).metaData;
        } catch (PackageManager.NameNotFoundException unused) {
            return null;
        }
    }

    public static boolean e(int i) {
        float f;
        float f2;
        float f3;
        float red = ((float) Color.red(i)) / 255.0f;
        float green = ((float) Color.green(i)) / 255.0f;
        float blue = ((float) Color.blue(i)) / 255.0f;
        if (red < 0.03928f) {
            f = red / 12.92f;
        } else {
            f = (float) Math.pow((double) ((red + 0.055f) / 1.055f), 2.4000000953674316d);
        }
        if (green < 0.03928f) {
            f2 = green / 12.92f;
        } else {
            f2 = (float) Math.pow((double) ((green + 0.055f) / 1.055f), 2.4000000953674316d);
        }
        if (blue < 0.03928f) {
            f3 = blue / 12.92f;
        } else {
            f3 = (float) Math.pow((double) ((blue + 0.055f) / 1.055f), 2.4000000953674316d);
        }
        if (Math.abs(1.05f / (((f3 * 0.0722f) + ((f2 * 0.7152f) + (f * 0.2126f))) + 0.05f)) >= 3.0f) {
            return true;
        }
        return false;
    }
}
