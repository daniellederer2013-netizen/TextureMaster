package defpackage;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.view.View;
import android.view.ViewTreeObserver;
import org.chromium.webapk.shell_apk.h2o.SplashActivity;

/* renamed from: s  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final class s implements ViewTreeObserver.OnGlobalLayoutListener {
    public final /* synthetic */ SplashActivity a;

    public s(SplashActivity splashActivity) {
        this.a = splashActivity;
    }

    public final void onGlobalLayout() {
        Bitmap bitmap;
        SplashActivity splashActivity = this.a;
        if (splashActivity.b.getWidth() != 0 && splashActivity.b.getHeight() != 0) {
            splashActivity.b.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            View view = splashActivity.b;
            int width = view.getWidth();
            int height = view.getHeight();
            if (width == 0 || height == 0) {
                bitmap = null;
            } else {
                float min = Math.min(1.0f, ((float) 12582912) / ((float) ((width * 4) * height)));
                int round = Math.round(((float) width) * min);
                int round2 = Math.round(((float) height) * min);
                Matrix matrix = new Matrix();
                matrix.postScale(min, min);
                bitmap = Bitmap.createBitmap(round, round2, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(bitmap);
                canvas.concat(matrix);
                view.draw(canvas);
            }
            splashActivity.c = bitmap;
            p pVar = splashActivity.f;
            pVar.b = true;
            pVar.a();
        }
    }
}
