package defpackage;

/* renamed from: C  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public abstract /* synthetic */ class C {
}
