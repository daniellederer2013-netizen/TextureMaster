package defpackage;

import org.chromium.webapk.shell_apk.h2o.SplashContentProvider;

/* renamed from: u  reason: default package */
/* compiled from: chromium-WebApk.apk-default-1 */
public final /* synthetic */ class u implements Runnable {
    public final void run() {
        SplashContentProvider.a((byte[]) null);
    }
}
